#!/bin/bash

mv 0.png lightspinny.0@2x.png && mv 1.png lightspinny.0@3x.png && mv 2.png lightspinny.1@2x.png && mv 3.png lightspinny.1@3x.png && mv 4.png lightspinny.2@2x.png && mv 5.png lightspinny.2@3x.png && mv 6.png lightspinny.3@2x.png && mv 7.png lightspinny.3@3x.png && mv 8.png lightspinny.4@2x.png && mv 9.png lightspinny.4@3x.png &&  mv 10.png lightspinny.5@2x.png && mv 11.png lightspinny.5@3x.png &&  mv 12.png lightspinny.6@2x.png && mv 13.png lightspinny.6@3x.png && mv 14.png lightspinny.7@2x.png && mv 15.png lightspinny.7@3x.png && mv 16.png lightspinny.8@2x.png && mv 17.png lightspinny.8@3x.png && mv 18.png lightspinny.9@2x.png && mv 19.png lightspinny.9@3x.png && mv 20.png lightspinny.10@2x.png && mv 21.png lightspinny.10@3x.png && mv 22.png lightspinny.11@2x.png && mv 23.png lightspinny.11@3x.png


